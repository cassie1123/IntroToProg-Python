'''

Created by C.He
Date: Aug 17, 2018
Course: IT FDN 100 B - Assignment06
Purpose:
This project is to organize the code created for working with your ToDo.txt file into Functions and a Class.

'''
# --------------------- data code ----------------------
objFileName = "C:\_PythonClass\CassieHe_Assignment06\Todo.txt"
lstTodo = []

# --------------------- process code ----------------------


class TodoListProcessor(object):
    """ This class contains functions for processing Todo list """

    # 1) Make a function that loads each rows of data in the text file into a python Dictionary and adds it into a List
    @staticmethod
    def LoadData(filename, mylist):
        """ This function loads data from txt file into python List of Dictionaries """
        objFH = open(filename, "r")
        for line in objFH:
            row = {"Task": line.split(",")[0].strip(), "Priority": line.split(",")[1].strip()}
            mylist.append(row)
        objFH.close()

    # 2) Make a function that displays the contents of the List to the user
    @staticmethod
    def DisplayContent(mylist):
        """ This function displays the current contents of my list table """
        print("******* The current items ToDo are: *******")
        for row in mylist:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")

    # 3) Make a function that allows user to Add/Remove/Save tasks in the List using numbered choices
    @staticmethod
    def AddTask(mylist, task, priority):
        """ This function add new task to my list table """
        row = {"Task": task, "Priority": priority}
        mylist.append(row)
        print("The new task was added.")

    @staticmethod
    def RemoveTask(mylist, task):
        blnItemRemoved = False
        intRowNumber = 0
        while (intRowNumber < len(mylist)):
            if (task.lower() == str(list(dict(mylist[intRowNumber]).values())[0]).lower()):
                del mylist[intRowNumber]
                blnItemRemoved = True
            intRowNumber += 1
        if (blnItemRemoved == True):
            print("The task was removed.")
        else:
            print("I'm sorry, but I could not find that task.")

    # 4) Make a function that saves the data from table into the txt file when the program exits
    @staticmethod
    def SaveData(filename, mylist):
        """ This function saves the data from my list table into the txt file """
        objFH = open(filename, "w")
        for row in mylist:
            objFH.write(row["Task"] + "," + row["Priority"] + "\n")
        objFH.close()
        print("Data saved to file!")

# --------------------- presentation (I/O) ----------------------
# Call the LoadData() function


TodoListProcessor.LoadData(objFileName, lstTodo)

# Display Menu of Options
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = input("Please choose from [1-5]:")

    if (strChoice.strip() == '1'):
        TodoListProcessor.DisplayContent(lstTodo)
        continue
    elif (strChoice.strip() == '2'):
        strNewTask = input("Enter the name of new task: ")
        strNewPriority = input("Enter the priority of new task: ")
        TodoListProcessor.AddTask(lstTodo, strNewTask, strNewPriority)
        continue
    elif (strChoice.strip() == '3'):
        strRemoveTask = input("Enter the name of the task you want to remove: ")
        TodoListProcessor.RemoveTask(lstTodo, strRemoveTask)
        continue
    elif (strChoice.strip() == '4'):
        TodoListProcessor.SaveData(objFileName, lstTodo)
        continue
    elif (strChoice.strip() == '5'):
        TodoListProcessor.SaveData(objFileName, lstTodo)
        break
