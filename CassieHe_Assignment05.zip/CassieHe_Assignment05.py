'''

Created by C.He
Date: Aug 11, 2018
Course: IT FDN 100 B - Assignment05
Purpose:
This project is to create a new script that manages a "ToDo list”.
The ToDo file will contain two columns of data (Task, Priority) which you store in a Python dictionary.
Each Dictionary will represent one row of data.
These rows of data are added to a Python List to create a table of data.

'''

# Use a for loop to load each row of data from the ToDo.txt file into a Python dictionary.
# Then place the data into a new dictionary object.
lstToDo = []
dicTodo = {}
objFH = open("C:\\_PythonClass\\CassieHe_Assignment05\\Todo.txt",'r')
for line in objFH:
    dicToDo = {"Task": line.split(",")[0].strip(), "Priority": line.split(",")[1].strip()}
    # Add the new dictionary “row” into a Python list object (now the data will be managed as a table).
    lstToDo.append(dicToDo)
objFH.close()
# Display the contents of the List to the user.
print("Below is the current content of the Todo.txt file.\n", lstToDo)
print("=================================")
# Allow the user to Add or Remove tasks from the list using numbered choices. Something like this would work:
#     Menu of Options
#     1) Show current data
#     2) Add a new item.
#     3) Remove an existing item.
#     4) Save Data to File
#     5) Exit Program
while(True):
    print("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)
    strChoice = input("Please choose the number [1-5] from the menu below: ")
    #1） Show current data
    if(strChoice.strip() == '1'):
        print(lstToDo)
        continue
    #2) Add a new item
    elif(strChoice.strip() == '2'):
        # Check if the item already exists
        while(True):
            strNewTask = input("Enter a new task:")
            blnFound = False
            for dicRow in lstToDo:
                if (dicRow["Task"].lower() == strNewTask.lower()):
                    print("The task you entered already exist.")
                    blnFound = True
                    break
                else: blnFound = False
            if not blnFound:
                strNewPriority = input("Enter the priority of the new task:")
                dicNewToDo = {"Task": strNewTask, "Priority": strNewPriority}
                lstToDo.append(dicNewToDo)
                print("New task has been added to the list.")
                break
        continue
    # 3) Remove an existing item
    elif(strChoice.strip() == '3'):
        while(True):
            strRemoveTask = input("Enter the task name you want to remove:")
            blnFound = False
            for dicRow in lstToDo:
                if(dicRow["Task"].lower() == strRemoveTask.lower()):
                    lstToDo.remove(dicRow)
                    blnFound = True
                    break
            if blnFound:
                print("Task has been successfully removed.")
                break
            else: print("The task you want to remove does not exit.")
        continue
    # 4) Save Data to File
    elif(strChoice.strip() == '4'):
        objFH = open("C:\\_PythonClass\\CassieHe_Assignment05\\Todo.txt", 'w')
        for dicRow in lstToDo:
            objFH.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
        objFH.close()
        print("Data has been saved to Todo.txt file.")
        continue
    # 5) Exit Program
    elif(strChoice.strip() == '5'):
        objFH = open("C:\\_PythonClass\\CassieHe_Assignment05\\Todo.txt", 'w')
        for dicRow in lstToDo:
            # Save the data from the table into the Todo.txt file when the program exits.
            objFH.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
        objFH.close()
        break


